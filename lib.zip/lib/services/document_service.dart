// document_service.dart (content reconstructed based on session history)
