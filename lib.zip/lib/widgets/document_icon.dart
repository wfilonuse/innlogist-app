// document_icon.dart (content reconstructed based on session history)
