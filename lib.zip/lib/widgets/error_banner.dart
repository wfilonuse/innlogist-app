// error_banner.dart (content reconstructed based on session history)
