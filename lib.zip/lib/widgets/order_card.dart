// order_card.dart (content reconstructed based on session history)
