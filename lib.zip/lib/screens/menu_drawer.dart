// menu_drawer.dart (content reconstructed based on session history)
